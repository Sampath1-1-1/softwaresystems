#!/bin/bash
# secure_gnome.sh

# Lock the screen
xdg-screensaver lock

